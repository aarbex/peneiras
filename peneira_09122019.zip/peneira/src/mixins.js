const globalMixins = {
  data() {
    return {
      apiUrl: "https://peneira.sccorinthians.com.br"
    };
  }
};

export default globalMixins;
