let baseUrl = "";

export const apiHost = baseUrl;
